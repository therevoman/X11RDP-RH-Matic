extern "C" {
void my_access(int *p);
void *my_alloc(unsigned sz);
}
